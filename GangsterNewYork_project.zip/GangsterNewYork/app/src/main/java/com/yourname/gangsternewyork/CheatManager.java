package com.yourname.gangsternewyork;

public class CheatManager {

    public boolean speedBoost = false;
    public boolean godMode = false;      // reserved for when a health/damage system is added
    public boolean infiniteRun = false;  // reserved for a stamina system if you add one

    public void toggleSpeedBoost() { speedBoost = !speedBoost; }
    public void toggleGodMode() { godMode = !godMode; }
    public void toggleInfiniteRun() { infiniteRun = !infiniteRun; }

    // Multiplier applied to base player speed when speedBoost is active
    public float getSpeedMultiplier() {
        return speedBoost ? 2.0f : 1.0f;
    }
}
